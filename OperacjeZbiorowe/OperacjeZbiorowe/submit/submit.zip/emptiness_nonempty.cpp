//Stanislaw Kucharski
#include "bitwise_operations.h"

//programy okreslaja czy SET1 jest pusty lub niepusty

bool Emptiness(int Set1) {
	if (Set1 == 0) return true;
	else return false;
}

bool Nonempty(int Set1) {
	if (Set1 == 0) return false;
	else return true;
}